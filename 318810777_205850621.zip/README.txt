API Documentation link: https://app.swaggerhub.com/apis-docs/IdoKraicer/FoodGod/1.0.0

318810777 205850621

Development estimation time:
Client Side - 5 hours
Server Side - 15 hours

